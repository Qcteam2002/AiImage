-- Create database and basic setup
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table will be created by migrations
-- This is just for basic database setup
