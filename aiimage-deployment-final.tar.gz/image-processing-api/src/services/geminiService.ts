import { GoogleGenAI } from '@google/genai';
import { config } from '../config';
import sharp from 'sharp';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

export interface ImageProcessingOptions {
  modelImagePath: string;
  productImagePath: string;
  prompt?: string;
}

export interface ProductImageProcessingOptions {
  productImagePath: string;
  backgroundImagePath?: string;
  prompt?: string;
}

export interface ProcessingResult {
  success: boolean;
  resultImagePath?: string;
  error?: string;
}

export class GeminiService {
  private genAI: GoogleGenAI;
  
  // Use Gemini 2.0 for image generation (following api.py reference)
  private models = [
    "gemini-2.0-flash-exp"   // Same model as api.py reference
  ];
  
  constructor() {
    if (!config.gemini.apiKey) {
      throw new Error('Gemini API key is required');
    }
    this.genAI = new GoogleGenAI({
      apiKey: config.gemini.apiKey
    });
    
    console.log('🤖 Gemini 2.0 image model configured (following api.py reference):');
    console.log(`   - ${this.models[0]} (Image generation with TEXT+IMAGE response)`);
    console.log('📸 Will send user uploaded images + prompt to Gemini');
  }
  
  // Helper method to get model configuration
  getAvailableModels(): string[] {
    return [...this.models];
  }
  
  // Helper method to get image mime type
  private getImageMimeType(filePath: string): string {
    const ext = path.extname(filePath).toLowerCase();
    switch (ext) {
      case '.jpg':
      case '.jpeg':
        return 'image/jpeg';
      case '.png':
        return 'image/png';
      case '.webp':
        return 'image/webp';
      case '.gif':
        return 'image/gif';
      default:
        return 'image/jpeg'; // Default fallback
    }
  }
  
  async processImages(options: ImageProcessingOptions): Promise<ProcessingResult> {
    try {
      const { modelImagePath, productImagePath, prompt } = options;
      
      console.log('🎨 Processing with Gemini 2.0 Image Generation (api.py style)...');
      console.log('📸 Model image:', modelImagePath);
      console.log('👔 Product image:', productImagePath);
      
      // Read and convert images to base64
      const modelImageBase64 = fs.readFileSync(modelImagePath, 'base64');
      const productImageBase64 = fs.readFileSync(productImagePath, 'base64');
      console.log('✅ Images converted to base64');
      
      // Detect image mime types
      const modelMimeType = this.getImageMimeType(modelImagePath);
      const productMimeType = this.getImageMimeType(productImagePath);
      console.log(`📸 Model image type: ${modelMimeType}`);
      console.log(`👔 Product image type: ${productMimeType}`);
      
      // Create the prompt for fashion image generation with uploaded images
      const fashionPrompt = prompt || `
        Generate an artistic fashion image based on the two provided images:
        - First image: The model/person 
        - Second image: The clothing/product
        
        Please create and return an image showing the person from the first image wearing the clothing from the second image.
        Use artistic styling with clean composition and modern aesthetic.
        Focus on combining the model's pose with the product's design and colors.
        Make it visually appealing with good color harmony and artistic flair.
        Style: fashion illustration, artistic, stylized, not photorealistic.
        
        Please generate and return the fashion image as your response.
      `;
      
      // Prepare content with images and text (simplified format)
      const contents = [
        { text: fashionPrompt },
        { 
          inlineData: {
            mimeType: modelMimeType,
            data: modelImageBase64
          }
        },
        { 
          inlineData: {
            mimeType: productMimeType, 
            data: productImageBase64
          }
        }
      ];

      // Try Gemini 2.0 image generation with user uploaded images (api.py style)
      let response;
      let lastError: any = null;
      
      const currentModel = this.models[0]; // Using 2.0 model like api.py
      console.log(`🤖 Using model: ${currentModel}`);
      
      let retries = 3; // More retries for single model
      
      while (retries > 0) {
        try {
          response = await this.genAI.models.generateContent({
            model: currentModel,
            contents: contents, // Send images + text
            config: {
              responseModalities: ["Text", "Image"] // Following api.py reference (camelCase)
            }
          });
          console.log(`✅ Success with ${currentModel}!`);
          break; // Success!
        } catch (error: any) {
          lastError = error;
          console.log(`⚠️ ${currentModel} failed, retries left: ${retries - 1}`);
          
          if (error?.message?.includes('quota') || error?.status === 429) {
            if (retries > 1) {
              console.log('🔄 Quota exceeded, waiting 60s before retry...');
              await new Promise(resolve => setTimeout(resolve, 60000)); // Wait for quota reset
              retries--;
            } else {
              console.log(`❌ ${currentModel} quota exhausted completely`);
              break; // No more retries
            }
          } else {
            console.log(`❌ ${currentModel} error (not quota): ${error?.message}`);
            if (retries > 1) {
              console.log('🔄 Retrying in 5s...');
              await new Promise(resolve => setTimeout(resolve, 5000));
              retries--;
            } else {
              break; // No more retries
            }
          }
        }
      }
      
      // If model failed, use mock fallback
      if (!response) {
        console.log('🎭 Gemini 2.0 failed, using mock fallback for testing...');
        console.log('📋 Last error:', lastError?.message || 'Unknown error');
        return await this.createMockResult();
      }

      console.log('✅ Gemini response received');

      // Process the response
      if (!response.candidates || response.candidates.length === 0) {
        throw new Error('No candidates returned from Gemini');
      }

      const candidate = response.candidates[0];
      if (!candidate.content || !candidate.content.parts) {
        throw new Error('No content parts in Gemini response');
      }

      // Find image data in response
      let imageData: Buffer | null = null;
      let textResponse: string = '';

      for (const part of candidate.content.parts) {
        if (part.text) {
          textResponse += part.text;
          console.log('📝 Gemini text:', part.text);
        } else if (part.inlineData && part.inlineData.data) {
          console.log('🖼️ Found generated image data');
          imageData = Buffer.from(part.inlineData.data, "base64");
        }
      }

      if (!imageData) {
        throw new Error('No image data found in Gemini response');
      }

      // Save the generated image (api.py style)
      const outputFileName = `gemini_2.0_fashion_${uuidv4()}.png`;
      const outputPath = path.join(config.upload.uploadPath, 'generated', outputFileName);
      
      // Ensure the generated directory exists
      const generatedDir = path.dirname(outputPath);
      if (!fs.existsSync(generatedDir)) {
        fs.mkdirSync(generatedDir, { recursive: true });
      }

      // Save the generated image
      fs.writeFileSync(outputPath, imageData);
      console.log(`💾 Image saved: ${outputPath}`);

      return {
        success: true,
        resultImagePath: outputPath
      };
      
    } catch (error) {
      console.error('❌ Gemini processing error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    }
  }

  async processProductImages(options: ProductImageProcessingOptions): Promise<ProcessingResult> {
    try {
      const { productImagePath, backgroundImagePath, prompt } = options;
      
      console.log('🎨 Processing product image with Gemini 2.0 (api.py style)...');
      console.log('📦 Product image:', productImagePath);
      if (backgroundImagePath) {
        console.log('🖼️ Background image:', backgroundImagePath);
      }
      
      // Read and convert product image to base64
      const productImageBase64 = fs.readFileSync(productImagePath, 'base64');
      console.log('✅ Product image converted to base64');
      
      // Detect product image mime type
      const productMimeType = this.getImageMimeType(productImagePath);
      console.log(`📦 Product image type: ${productMimeType}`);
      
      // Prepare contents array for Gemini
      const contents: any[] = [];
      
      // Create the prompt for product image optimization
      let optimizationPrompt = prompt;
      
      if (!optimizationPrompt) {
        if (backgroundImagePath) {
          optimizationPrompt = `
            Optimize this product image by combining it with the provided background image.
            Create a professional, clean composition with the product prominently displayed.
            Maintain the original product colors and details while seamlessly blending with the background.
            Style: professional product photography, clean composition, commercial quality.
            Please generate and return the optimized product image as your response.
          `;
        } else {
          optimizationPrompt = `
            Optimize this product image with a clean, professional background.
            Remove any distracting elements and enhance the product presentation.
            Use a neutral background that makes the product stand out.
            Style: professional product photography, clean white or neutral background, commercial quality.
            Please generate and return the optimized product image as your response.
          `;
        }
      }
      
      // Add prompt
      contents.push({ text: optimizationPrompt });
      
      // Add product image
      contents.push({ 
        inlineData: {
          mimeType: productMimeType,
          data: productImageBase64
        }
      });
      
      // Add background image if provided
      if (backgroundImagePath) {
        const backgroundImageBase64 = fs.readFileSync(backgroundImagePath, 'base64');
        const backgroundMimeType = this.getImageMimeType(backgroundImagePath);
        console.log(`🖼️ Background image type: ${backgroundMimeType}`);
        
        contents.push({ 
          inlineData: {
            mimeType: backgroundMimeType,
            data: backgroundImageBase64
          }
        });
        
        console.log('✅ Background image converted to base64');
      }

      // Try Gemini 2.0 image generation for product optimization
      let response;
      let lastError: any = null;
      
      const currentModel = this.models[0]; // Using 2.0 model like api.py
      console.log(`🤖 Using model: ${currentModel} for product optimization`);
      
      let retries = 3; 
      
      while (retries > 0) {
        try {
          response = await this.genAI.models.generateContent({
            model: currentModel,
            contents: contents, 
            config: {
              responseModalities: ["Text", "Image"] // Following api.py reference
            }
          });
          console.log(`✅ Success with ${currentModel}!`);
          break; // Success!
        } catch (error: any) {
          lastError = error;
          console.log(`⚠️ ${currentModel} failed, retries left: ${retries - 1}`);
          
          if (error?.message?.includes('quota') || error?.status === 429) {
            if (retries > 1) {
              console.log('🔄 Quota exceeded, waiting 60s before retry...');
              await new Promise(resolve => setTimeout(resolve, 60000));
              retries--;
            } else {
              console.log(`❌ ${currentModel} quota exhausted completely`);
              break;
            }
          } else {
            console.log(`❌ ${currentModel} error (not quota): ${error?.message}`);
            if (retries > 1) {
              console.log('🔄 Retrying in 5s...');
              await new Promise(resolve => setTimeout(resolve, 5000));
              retries--;
            } else {
              break;
            }
          }
        }
      }
      
      // If model failed, use mock fallback
      if (!response) {
        console.log('🎭 Gemini 2.0 failed for product processing, using mock fallback...');
        console.log('📋 Last error:', lastError?.message || 'Unknown error');
        return await this.createProductMockResult();
      }

      console.log('✅ Gemini response received for product processing');

      // Process the response
      if (!response.candidates || response.candidates.length === 0) {
        throw new Error('No candidates returned from Gemini');
      }

      const candidate = response.candidates[0];
      if (!candidate.content || !candidate.content.parts) {
        throw new Error('No content parts in Gemini response');
      }

      // Find image data in response
      let imageData: Buffer | null = null;
      let textResponse: string = '';

      for (const part of candidate.content.parts) {
        if (part.text) {
          textResponse += part.text;
          console.log('📝 Gemini text:', part.text);
        } else if (part.inlineData && part.inlineData.data) {
          console.log('🖼️ Found generated product image data');
          imageData = Buffer.from(part.inlineData.data, "base64");
        }
      }

      if (!imageData) {
        throw new Error('No image data found in Gemini response');
      }

      // Save the generated image
      const outputFileName = `gemini_2.0_product_${uuidv4()}.png`;
      const outputPath = path.join(config.upload.uploadPath, 'generated', outputFileName);
      
      // Ensure the generated directory exists
      const generatedDir = path.dirname(outputPath);
      if (!fs.existsSync(generatedDir)) {
        fs.mkdirSync(generatedDir, { recursive: true });
      }

      // Save the generated image
      fs.writeFileSync(outputPath, imageData);
      console.log(`💾 Product image saved: ${outputPath}`);

      return {
        success: true,
        resultImagePath: outputPath
      };
      
    } catch (error) {
      console.error('❌ Product image processing error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    }
  }
  
  // Fallback mock result when Gemini 2.0 fails
  private async createMockResult(): Promise<ProcessingResult> {
    console.log('🎨 Creating mock fashion result (Gemini 2.0 unavailable)...');
    
    const outputFileName = `gemini_2.0_mock_${uuidv4()}.png`;
    const outputPath = path.join(config.upload.uploadPath, 'generated', outputFileName);
    
    // Ensure the generated directory exists
    const generatedDir = path.dirname(outputPath);
    if (!fs.existsSync(generatedDir)) {
      fs.mkdirSync(generatedDir, { recursive: true });
    }

    // Create a stylish mock fashion image
    await sharp({
      create: {
        width: 800,
        height: 1000,
        channels: 3,
        background: { r: 245, g: 245, b: 250 }
      }
    })
    .composite([
      {
        input: Buffer.from(`
          <svg width="800" height="1000">
            <defs>
              <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#667eea;stop-opacity:0.1" />
                <stop offset="100%" style="stop-color:#764ba2;stop-opacity:0.1" />
              </linearGradient>
            </defs>
            <rect width="800" height="1000" fill="url(#bg)"/>
            <rect x="150" y="150" width="500" height="600" fill="#f8f9fa" stroke="#e9ecef" stroke-width="2" rx="20"/>
            <text x="400" y="200" text-anchor="middle" font-family="Arial" font-size="24" font-weight="bold" fill="#495057">🎭 AI Fashion Preview</text>
            <text x="400" y="250" text-anchor="middle" font-family="Arial" font-size="18" fill="#6c757d">Gemini 2.0 Unavailable</text>
            <text x="400" y="280" text-anchor="middle" font-family="Arial" font-size="12" fill="#868e96">Following api.py reference</text>
            <text x="400" y="320" text-anchor="middle" font-family="Arial" font-size="16" fill="#495057">✨ Enable billing for real AI</text>
            <text x="400" y="350" text-anchor="middle" font-family="Arial" font-size="14" fill="#6c757d">console.cloud.google.com/billing</text>
            <circle cx="400" cy="450" r="80" fill="#e9ecef" stroke="#dee2e6" stroke-width="2"/>
            <text x="400" y="460" text-anchor="middle" font-family="Arial" font-size="36" fill="#6c757d">👗</text>
            <text x="400" y="550" text-anchor="middle" font-family="Arial" font-size="14" fill="#495057">Premium Fashion AI</text>
            <text x="400" y="570" text-anchor="middle" font-family="Arial" font-size="14" fill="#6c757d">Cost: ~$0.002-0.008/image</text>
            <text x="400" y="650" text-anchor="middle" font-family="Arial" font-size="12" fill="#868e96">Ready to generate real AI fashion when billing enabled</text>
            <rect x="200" y="700" width="400" height="2" fill="#dee2e6"/>
            <text x="400" y="730" text-anchor="middle" font-family="Arial" font-size="10" fill="#adb5bd">AIImage App - Powered by Gemini AI</text>
          </svg>
        `),
        top: 0,
        left: 0
      }
    ])
    .png()
    .toFile(outputPath);

    return {
      success: true,
      resultImagePath: outputPath
    };
  }

  // Fallback mock result for product image processing when Gemini 2.0 fails
  private async createProductMockResult(): Promise<ProcessingResult> {
    console.log('🎨 Creating mock product result (Gemini 2.0 unavailable)...');
    
    const outputFileName = `gemini_2.0_product_mock_${uuidv4()}.png`;
    const outputPath = path.join(config.upload.uploadPath, 'generated', outputFileName);
    
    // Ensure the generated directory exists
    const generatedDir = path.dirname(outputPath);
    if (!fs.existsSync(generatedDir)) {
      fs.mkdirSync(generatedDir, { recursive: true });
    }

    // Create a stylish mock product image
    await sharp({
      create: {
        width: 800,
        height: 800,
        channels: 3,
        background: { r: 250, g: 250, b: 250 }
      }
    })
    .composite([
      {
        input: Buffer.from(`
          <svg width="800" height="800">
            <defs>
              <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#f8f9fa;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#e9ecef;stop-opacity:1" />
              </linearGradient>
              <linearGradient id="productGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#6c7380;stop-opacity:0.1" />
                <stop offset="100%" style="stop-color:#495057;stop-opacity:0.1" />
              </linearGradient>
            </defs>
            <rect width="800" height="800" fill="url(#bg)"/>
            <rect x="150" y="150" width="500" height="500" fill="url(#productGrad)" stroke="#dee2e6" stroke-width="2" rx="20"/>
            <text x="400" y="200" text-anchor="middle" font-family="Arial" font-size="24" font-weight="bold" fill="#495057">🔧 Product Image Tools</text>
            <text x="400" y="250" text-anchor="middle" font-family="Arial" font-size="18" fill="#6c757d">Gemini 2.0 Unavailable</text>
            <text x="400" y="280" text-anchor="middle" font-family="Arial" font-size="12" fill="#868e96">Following api.py reference</text>
            <text x="400" y="320" text-anchor="middle" font-family="Arial" font-size="16" fill="#495057">✨ Enable billing for real AI</text>
            <text x="400" y="350" text-anchor="middle" font-family="Arial" font-size="14" fill="#6c757d">console.cloud.google.com/billing</text>
            <circle cx="400" cy="430" r="60" fill="#e9ecef" stroke="#dee2e6" stroke-width="2"/>
            <text x="400" y="440" text-anchor="middle" font-family="Arial" font-size="32" fill="#6c7380">📦</text>
            <text x="400" y="520" text-anchor="middle" font-family="Arial" font-size="14" fill="#495057">Product Optimization AI</text>
            <text x="400" y="540" text-anchor="middle" font-family="Arial" font-size="14" fill="#6c757d">Background removal & enhancement</text>
            <text x="400" y="580" text-anchor="middle" font-family="Arial" font-size="12" fill="#868e96">Ready for real product optimization when billing enabled</text>
            <rect x="200" y="620" width="400" height="2" fill="#dee2e6"/>
            <text x="400" y="650" text-anchor="middle" font-family="Arial" font-size="10" fill="#adb5bd">AIImage App - Product Tools - Powered by Gemini AI</text>
          </svg>
        `),
        top: 0,
        left: 0
      }
    ])
    .png()
    .toFile(outputPath);

    return {
      success: true,
      resultImagePath: outputPath
    };
  }

  // Helper method to validate image files
  static validateImageFile(filePath: string): boolean {
    try {
      const stats = fs.statSync(filePath);
      if (!stats.isFile()) return false;
      
      const ext = path.extname(filePath).toLowerCase();
      return ['.jpg', '.jpeg', '.png', '.webp', '.gif'].includes(ext);
    } catch {
      return false;
    }
  }
}

